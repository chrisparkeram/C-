﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1) && int.TryParse(txtNumero2.Text, out int num2))
            {
                txtResultado.Text = (num1 + num2).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void btnResta_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1) && int.TryParse(txtNumero2.Text, out int num2))
            {
                txtResultado.Text = (num1 - num2).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1) && int.TryParse(txtNumero2.Text, out int num2))
            {
                txtResultado.Text = (num1 * num2).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1) && int.TryParse(txtNumero2.Text, out int num2))
            {
                if (num2 != 0)
                {
                    txtResultado.Text = (num1 / (double)num2).ToString();
                }
                else
                {
                    MessageBox.Show("ERROR, NO SE PUEDE DIVIDIR EN CERO");
                }
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void btnCuadrado_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1))
            {
                txtResultado.Text = Math.Pow(num1, 2).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void btnCubo_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1))
            {
                txtResultado.Text = Math.Pow(num1, 3).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }
        private void btnRaiz_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out int num1))
            {
                txtResultado.Text = Math.Sqrt(num1).ToString();
            }
            else
            {
                MessageBox.Show("ERROR, FAVOR INGRESAR NUMEROS VALIDOS");
            }
        }

        private void Borrar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
