﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class Form1 : Form
    {
        private List<CitaMedica> citas = new List<CitaMedica>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listRegistros_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string documento = txtDocumento.Text;
            string nombre = txtNombre.Text;
            string doctor = cmbDoctor.SelectedItem.ToString();
            string consultorio = cmbConsul.SelectedItem.ToString();
            DateTime horario = dateTimePicker1.Value;

            CitaMedica cita = new CitaMedica(documento, nombre, doctor, consultorio, horario);
            citas.Add(cita);

            listBoxCitas.Items.Add(cita.ToString());

            // Limpiar campos después de guardar
            txtDocumento.Clear();
            txtNombre.Clear();
            cmbDoctor.SelectedIndex = -1;
            cmbConsul.SelectedIndex = -1;
            dateTimePicker1.Value = DateTime.Now;
        }

        private void cmbDoctor_SelectedIndexChanged(object sender, EventArgs e)
        {
            string doctor;
            doctor = cmbDoctor.SelectedItem.ToString();
            switch (doctor)
            {
                case "Dr. Heladio": .Text = "Dr. Heladio"; break;
                case "Dra. Maria": .Text = "Dra. Maaria"; break;
                case "Dr. Nicolas": .Text = "Dr. Nicolas"; break;
                default: .Text = "Error"; break;
            }

        }

        private void cmbConsul_SelectedIndexChanged(object sender, EventArgs e)
        {
            string consultorio;
            consultorio = cmbDoctor.SelectedItem.ToString();
            switch (consultorio)
            {
                case "Consultorio 101": .Text = "Consultorio 101"; break;
                case "Consultorio 102": .Text = "Consultorio 102"; break;
                case "Consultorio 103": .Text = "Consultorio 103"; break;
                default: .Text = "Error"; break;
            }
        }
    }
}
