﻿namespace Proyecto_Agendador
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNOMBRE = new System.Windows.Forms.TextBox();
            this.txtDOCUMENTO = new System.Windows.Forms.TextBox();
            this.cboDOCTOR = new System.Windows.Forms.ComboBox();
            this.cboCONSUL = new System.Windows.Forms.ComboBox();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aRCHIVOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guardarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNFORMACIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aUTORESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.christianMeloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nicolasRubianoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSALIR = new System.Windows.Forms.Button();
            this.btnBORRAR = new System.Windows.Forms.Button();
            this.btnGUARDAR = new System.Windows.Forms.Button();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "DOCUMENTO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOMBRE";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "DOCTOR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(350, 192);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "CONSULTORIO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(61, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "HORARIO";
            // 
            // txtNOMBRE
            // 
            this.txtNOMBRE.Location = new System.Drawing.Point(195, 145);
            this.txtNOMBRE.Name = "txtNOMBRE";
            this.txtNOMBRE.Size = new System.Drawing.Size(115, 20);
            this.txtNOMBRE.TabIndex = 5;
            // 
            // txtDOCUMENTO
            // 
            this.txtDOCUMENTO.Location = new System.Drawing.Point(196, 105);
            this.txtDOCUMENTO.Name = "txtDOCUMENTO";
            this.txtDOCUMENTO.Size = new System.Drawing.Size(114, 20);
            this.txtDOCUMENTO.TabIndex = 6;
            // 
            // cboDOCTOR
            // 
            this.cboDOCTOR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cboDOCTOR.FormattingEnabled = true;
            this.cboDOCTOR.Items.AddRange(new object[] {
            "Dr.Heladio",
            "Dr.Nicolas",
            "Dr.Chris",
            "Dra.Maria"});
            this.cboDOCTOR.Location = new System.Drawing.Point(196, 184);
            this.cboDOCTOR.Name = "cboDOCTOR";
            this.cboDOCTOR.Size = new System.Drawing.Size(115, 21);
            this.cboDOCTOR.TabIndex = 7;
            // 
            // cboCONSUL
            // 
            this.cboCONSUL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cboCONSUL.FormattingEnabled = true;
            this.cboCONSUL.Items.AddRange(new object[] {
            "Consultorio 101",
            "Consultorio 102",
            "Consultorio 103",
            "Consultorio 104"});
            this.cboCONSUL.Location = new System.Drawing.Point(480, 184);
            this.cboCONSUL.Name = "cboCONSUL";
            this.cboCONSUL.Size = new System.Drawing.Size(111, 21);
            this.cboCONSUL.TabIndex = 8;
            // 
            // rtbEditor
            // 
            this.rtbEditor.Location = new System.Drawing.Point(26, 293);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(885, 134);
            this.rtbEditor.TabIndex = 9;
            this.rtbEditor.Text = "";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(195, 232);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(192, 20);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(262, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(329, 36);
            this.label6.TabIndex = 11;
            this.label6.Text = "AGENDADOR DE CITAS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(681, 81);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(230, 195);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aRCHIVOToolStripMenuItem,
            this.iNFORMACIONToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(945, 24);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aRCHIVOToolStripMenuItem
            // 
            this.aRCHIVOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.guardarToolStripMenuItem,
            this.abrirToolStripMenuItem});
            this.aRCHIVOToolStripMenuItem.Name = "aRCHIVOToolStripMenuItem";
            this.aRCHIVOToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.aRCHIVOToolStripMenuItem.Text = "ARCHIVO";
            // 
            // guardarToolStripMenuItem
            // 
            this.guardarToolStripMenuItem.Name = "guardarToolStripMenuItem";
            this.guardarToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.guardarToolStripMenuItem.Text = "Guardar";
            this.guardarToolStripMenuItem.Click += new System.EventHandler(this.guardarToolStripMenuItem_Click);
            // 
            // iNFORMACIONToolStripMenuItem
            // 
            this.iNFORMACIONToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aUTORESToolStripMenuItem});
            this.iNFORMACIONToolStripMenuItem.Name = "iNFORMACIONToolStripMenuItem";
            this.iNFORMACIONToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.iNFORMACIONToolStripMenuItem.Text = "INFORMACION";
            // 
            // aUTORESToolStripMenuItem
            // 
            this.aUTORESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.christianMeloToolStripMenuItem,
            this.nicolasRubianoToolStripMenuItem});
            this.aUTORESToolStripMenuItem.Name = "aUTORESToolStripMenuItem";
            this.aUTORESToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.aUTORESToolStripMenuItem.Text = "AUTORES";
            // 
            // christianMeloToolStripMenuItem
            // 
            this.christianMeloToolStripMenuItem.Name = "christianMeloToolStripMenuItem";
            this.christianMeloToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.christianMeloToolStripMenuItem.Text = "Christian Melo";
            // 
            // nicolasRubianoToolStripMenuItem
            // 
            this.nicolasRubianoToolStripMenuItem.Name = "nicolasRubianoToolStripMenuItem";
            this.nicolasRubianoToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.nicolasRubianoToolStripMenuItem.Text = "Nicolas Rubiano";
            // 
            // btnSALIR
            // 
            this.btnSALIR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSALIR.Location = new System.Drawing.Point(27, 479);
            this.btnSALIR.Name = "btnSALIR";
            this.btnSALIR.Size = new System.Drawing.Size(87, 41);
            this.btnSALIR.TabIndex = 14;
            this.btnSALIR.Text = "SALIR";
            this.btnSALIR.UseVisualStyleBackColor = true;
            this.btnSALIR.Click += new System.EventHandler(this.btnSALIR_Click_1);
            // 
            // btnBORRAR
            // 
            this.btnBORRAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBORRAR.Location = new System.Drawing.Point(425, 479);
            this.btnBORRAR.Name = "btnBORRAR";
            this.btnBORRAR.Size = new System.Drawing.Size(99, 40);
            this.btnBORRAR.TabIndex = 15;
            this.btnBORRAR.Text = "BORRAR";
            this.btnBORRAR.UseVisualStyleBackColor = true;
            this.btnBORRAR.Click += new System.EventHandler(this.btnBORRAR_Click_1);
            // 
            // btnGUARDAR
            // 
            this.btnGUARDAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGUARDAR.Location = new System.Drawing.Point(802, 476);
            this.btnGUARDAR.Name = "btnGUARDAR";
            this.btnGUARDAR.Size = new System.Drawing.Size(109, 43);
            this.btnGUARDAR.TabIndex = 16;
            this.btnGUARDAR.Text = "ENVIAR";
            this.btnGUARDAR.UseVisualStyleBackColor = true;
            this.btnGUARDAR.Click += new System.EventHandler(this.btnGUARDAR_Click_1);
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(945, 631);
            this.Controls.Add(this.btnGUARDAR);
            this.Controls.Add(this.btnBORRAR);
            this.Controls.Add(this.btnSALIR);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.cboCONSUL);
            this.Controls.Add(this.cboDOCTOR);
            this.Controls.Add(this.txtDOCUMENTO);
            this.Controls.Add(this.txtNOMBRE);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNOMBRE;
        private System.Windows.Forms.TextBox txtDOCUMENTO;
        private System.Windows.Forms.ComboBox cboDOCTOR;
        private System.Windows.Forms.ComboBox cboCONSUL;
        private System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aRCHIVOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guardarToolStripMenuItem;
        private System.Windows.Forms.Button btnSALIR;
        private System.Windows.Forms.Button btnBORRAR;
        private System.Windows.Forms.Button btnGUARDAR;
        private System.Windows.Forms.ToolStripMenuItem iNFORMACIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aUTORESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem christianMeloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nicolasRubianoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
    }
}