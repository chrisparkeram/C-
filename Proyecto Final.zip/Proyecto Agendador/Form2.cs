﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_Agendador
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void btnGUARDAR_Click(object sender, EventArgs e)
        {
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
        }

        private void cboCiudad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // Obtener la fecha seleccionada en el DateTimePicker
            DateTime fechaSeleccionada = dateTimePicker1.Value;

            // Formatear la fecha si es necesario, por ejemplo, en formato "dd/MM/yyyy"
            string fechaFormateada = fechaSeleccionada.ToString("dd/MM/yyyy");

            // Añadir texto al RichTextBox con la fecha
            //rtbEditor.AppendText($"\nVive en la ciudad de: {fechaFormateada}");
        }

        private void btnGUARDAR_Click_1(object sender, EventArgs e)
        {
            //Documento y nombre
            rtbEditor.Text = $"Su documento es {txtDOCUMENTO.Text} \n Su nombre es:{txtNOMBRE.Text}";
            //Doctor
            rtbEditor.AppendText($"\n Ud selecciono al : {cboDOCTOR.SelectedItem}");
            //Doctor
            rtbEditor.AppendText($"\n Ud Selecciono el : {cboCONSUL.SelectedItem}");
            //HORARIO
            // Añadir texto al RichTextBox con la fecha
            rtbEditor.AppendText($"\nSu cita elegida es : {dateTimePicker1.Value}");

        }

        private void btnSALIR_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBORRAR_Click_1(object sender, EventArgs e)
        {
            txtNOMBRE.Clear();
            txtDOCUMENTO.Clear();
            rtbEditor.Clear();
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (StreamWriter archivo = new StreamWriter("factura.txt", true))
            {
            }
        }
    }
}
   


